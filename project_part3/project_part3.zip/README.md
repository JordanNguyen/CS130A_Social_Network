# CS130A_Social_Network
CS130A Programming Project Part 3

Jordan Nguyen
Brandon Wicka

Instructions:

1.) Type 'make' in terminal
2.) Type './a.out' in terminal to run
3.) Follow the prompt given by the program
4.) You may choose to run the program with 10,000 pregenerated users 
found in generatedUsers.txt, generatedFriends.txt, and generatedRequests.txt
5.) Otherwise, you can run the program brand new and create your own 
saved data and users.
